# Manual Randomizer Setup Guide

## Required Software

- None

## Installation Procedures

Needs content.

## Joining a MultiWorld Game

Needs content.

## Multiplayer Manual

Needs content.

## Game Troubleshooting

Needs content.